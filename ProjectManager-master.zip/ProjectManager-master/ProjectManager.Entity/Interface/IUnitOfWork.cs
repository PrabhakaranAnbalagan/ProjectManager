﻿
namespace ProjectManager.Entity.Interface
{
    public interface IUnitOfWork
    {
    }
}
