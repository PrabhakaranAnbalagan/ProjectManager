﻿
namespace ProjectManager.Entity.Data
{
    public class User
    {
        public int UserId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public bool Active { get; set; }
    }
}
