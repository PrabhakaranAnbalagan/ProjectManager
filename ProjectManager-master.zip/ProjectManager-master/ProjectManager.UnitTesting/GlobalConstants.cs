﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using NUnit.Framework;

namespace ProjectManager.UnitTest
{
    public class GlobalConstants
    {
        public static int USER_ID;

        public static int PROJECT_ID;

        public static int TASK_ID;
    }
}
