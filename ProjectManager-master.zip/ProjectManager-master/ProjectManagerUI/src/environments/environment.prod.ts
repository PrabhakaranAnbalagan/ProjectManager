export const environment = {
  production: true,
  apiBaseUri: "http://localhost:85"
};
